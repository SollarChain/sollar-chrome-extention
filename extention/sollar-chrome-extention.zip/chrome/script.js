window.Buffer = ethereumjs.Buffer.Buffer
